local fishingRodMode = require("code.modes.fishing_rod")
local bookMode = require("code.modes.book")
local fishMode = require("code.modes.fish")

events.SKULL_RENDER:register(function(delta, block, item, entity, ctx)
   if block or not item then
      return bookMode:setMode(delta, block, item, entity, ctx)
   end
   local itemName = item:getName()
   local itemNameLower = itemName:lower()
   if itemNameLower:find("%a%sfish") then
      return fishMode:setMode(delta, block, item, entity, ctx)
   end
   return fishingRodMode:setMode(delta, block, item, entity, ctx)
end)

function events.tick()
   worldModel:newBlock("")
      :block("glass")
      :pos(player:getTargetedBlock(true):getPos() * 16 - 0.005 * 16)
      :scale(1.01)
end

worldModel:newBlock("a"):block("minecraft:grass_block")
-- worldModel:newBlock("b"):block("minecraft:gold_block"):pos(16, 0, 0)
-- worldModel:newItem("c"):item("minecraft:copper_bulb")