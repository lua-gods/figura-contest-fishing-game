local worldModelPart = models:newPart("world", "World")
local skullModel = models:newPart("world_skull", "Skull")
local skullModel2 = skullModel:newPart("")

worldModelPart:addChild(worldModel)
skullModel:setVisible(false)
skullModel2:addChild(worldModel)

models.world:setVisible(false)

local worldLastFrame = 2
local skullBlockLastFrame = 0
local renderUsingSkull = false
local skullBlockPos

worldModelPart.preRender = function(delta, context, part)
   worldLastFrame = avatarFrame + 2
   renderUsingSkull = false
end

function events.world_render()
   if avatarFrame > worldLastFrame then
      renderUsingSkull = true
      skullBlockPos = nil
      renderAsSkullItem = avatarFrame > skullBlockLastFrame
   end
end

local facingToOffset = {
   [1] = vec(-8, 0, -8),
   north = vec(-8, -4, -12),
   east = vec(-4, -4, -8),
   south = vec(-8, -4, -4),
   west = vec(-12, -4, -8),
}

local facingToRot = {
   north = 0,
   east = 4,
   south = 8,
   west = 12,
}

local firstPersonItemOffsets = {
   ["FIRST_PERSON_LEFT_HAND"] = vec(-16.96, 24.33, 0),
   ["FIRST_PERSON_RIGHT_HAND"] = vec(0.96, 24.33, 0),
}

local _ = models:newPart("", "WORLD") -- f3 bounding box
events.SKULL_RENDER:register(function(delta, block, item, entity, ctx)
   skullModel:visible(false)
   if renderUsingSkull and block then
      skullBlockLastFrame = avatarFrame + 2
      local blockPos = block:getPos()
      if not skullBlockPos then
         skullBlockPos = blockPos
      end
      local properties = block.properties
      if skullBlockPos == blockPos and properties then
         local rot = (tonumber(properties.rotation) or facingToRot[properties.facing]) * 22.5
         skullModel:visible(true)
            :rot(0, rot, 0)
            :pos()
         skullModel2:pos(-blockPos * 16 + facingToOffset[properties.facing or 1])
      end
   end
   if renderAsSkullItem and firstPersonItemOffsets[ctx] then
      renderAsSkullItem = false
      skullModel:setPos(firstPersonItemOffsets[ctx])
         :rot()
      skullModel:visible(true)
      local camRot = client.getViewer():getRot(delta)
      local camPos = client.getCameraPos()

      local fov = math.tan(math.rad(client.getFOV() / 2)) * 2
      -- local offset = vec(0, 0, 0)
      local mat = matrices.mat4()
      mat:translate(-camPos * 16)
      mat:rotateY(camRot.y)
         :rotateX(-camRot.x)
      -- mat:translate(0, 0, 16)
      -- mat:scale(1, 1, 1)
      mat:scale(1 / fov, 1 / fov, 0.75)
      skullModel2:setMatrix(mat)
   end
end)