local skullModes = require("code.skull_modes")
local customItemHelper = require("code.custom_item_helper")
local mode = skullModes.newMode()

local model = models:newPart("", "Skull")
model:newItem(""):setItem("minecraft:fishing_rod")
mode:setModel(model)

function mode.render(delta, block, item, entity, ctx)
   local mat, modelType = customItemHelper.getMatrix(entity, ctx, 2)

   model:setMatrix(mat)
end

return mode