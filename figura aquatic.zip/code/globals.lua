avatarTick = 0
avatarFrame = 0

worldModel = models:newPart(""):remove()

events.WORLD_TICK:register(function()
   avatarTick = avatarTick + 1
end)

events.WORLD_RENDER:register(function(delta)
   avatarFrame = avatarFrame + 1
end)